
# Lume Studio - Site Oficial

Este é o repositório do site da Lume Studio, produtora audiovisual especializada em vídeos criativos para redes sociais.

## Funcionalidades
- Layout responsivo e minimalista
- Vídeo de fundo na seção inicial
- Cards de portfólio com vídeos incorporados do YouTube
- Lista de serviços com botão CTA
- Formulário de contato funcional
- Botão flutuante do WhatsApp

## Como visualizar
Abra o arquivo `index.html` em um navegador moderno.

## Contato
- Email: lumestudiobr2025@gmail.com
- WhatsApp: (12) 3800-0000
- Instagram: [@lumestudiobrasil](https://www.instagram.com/lumestudiobrasil?igsh=ZW92dzFjbDVpeWF4)
